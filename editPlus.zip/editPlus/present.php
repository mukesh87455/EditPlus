<?php
    session_start();

    if(!isset($_SESSION["logged"]) || (isset($_SESSION["logged"]) && $_SESSION["logged"]==false))
    {
        /*
        echo '<script language="javascript">';
        echo 'alert("You need to login to continue")';
        echo '</script>';
         */

        //to catch failure
        $_SESSION["failed"]=true;

        header("Location: index.php");
    }

?>

<html>
    <head>
        <title>EditPlus - Collaborative Real Time Text Editor</title>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript" src="js_stuff/editor.js"></script>
        <script type="text/javascript" src="js_stuff/publish_present.js"></script>
        <script type="text/javascript" src="js_stuff/jquery-linedtextarea.js"></script>
        <link rel="stylesheet" type="text/css" href="styling_stuff/editor.css">
        <link rel="stylesheet" type="text/css" href="styling_stuff/jquery-linedtextarea.css">
        <link rel="icon" type="image/x-icon" href="fav/favicon.ico">
    </head>
    <body>
            <div id="upper_box">
                <div id="doc_info">DOCUMENT: <?php echo $_SESSION['token'];?></div><br><br>
                SHARING: 

                <?php
   
                    require_once("db_connection.php");
                    $username=$_SESSION["username"];
                    $doc_id=$_SESSION["document_info"];

                    $query = $mysqli->prepare("
                                                SELECT *
                                                FROM edit_permits
                                                WHERE doc_id=?
                                            ");

                    $query->bind_param("s", $doc_id);
                    $query->execute();
                    $result=$query->get_result();

                    if($row=$result->fetch_assoc())
                    {
                        $edit_status=$row['editable'];
                        echo $edit_status;
                    }

                    if($row['ownername']==$username)
                    {
                        //option to toggle sharing status
?>
                        <br>
                        <form method="POST" action="toggle_share.php">
                            <input type="submit" id="toggle_share" value="Toggle Sharing Status">
                        </form>


                <?php

                    }

                ?>

                </div>
                <div id="doc_title">
                   TITLE: 

                    <textarea id="title" maxlength="40" placeholder="ADD TITLE"></textarea> 

<br>
                <a href="#" onclick="publish(); return false"> Publish this document </a>
                <a href="" onclick='saveTextAsFile(); return false' class="btn btn-info" role="button">Download document</a>

                </div>

            
                <div id="user_info">
                    <?php echo "welcome ".$_SESSION['username']; ?> <br>
                    <a href="welcome.php">Homepage</a><br>
                    <a href="logout.php">Log Out</a>
                </div>

                <div id="contributors">
                    CONTRIBUTORS:
    <?php
        require_once("db_connection.php");

        $username=$_SESSION["username"];

        $query = $mysqli->prepare("
                                    SELECT DISTINCT username
                                    FROM user_docs
                                    WHERE doc_id=?
                                ");

        $query->bind_param("s", $_SESSION['document_info']);
        $query->execute();
        $result=$query->get_result();

        while($row=$result->fetch_assoc())
        {
            echo $row['username']." ";
        }
    ?>
                </div>
                
           </div>

            <div id="box">
                <div id="editor">
                    
<!--
                    <div id="editor_field" contenteditable='true' >Start typing here...</div>
-->

                    <textarea id="editor_field" class="lined" placeholder="Start typing here..." ></textarea>

                </div>
                
<script>
$(function() {
	$(".lined").linedtextarea(
		{selectedLine: 0}
	);
});
</script>

            </div>

           <div id="chat">
            The Chat comes here
           </div>

    </body>
</html>
