<?php 

require_once("functions.php");

if(!isset($_SESSION['token']))
{
    die("You don't have an edit token ");
}

print (update_editor($_POST["editor_contents"],$_POST["title"]));

?>
