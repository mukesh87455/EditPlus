<?php

    session_start();
    
    if(isset($_SESSION["failed"]))
    {

        unset($_SESSION["failed"]);
        echo "You must be logged in to continue";
    }

    if(isset($_SESSION["registered"]))
    {
        if($_SESSION["registered"]==false)
        {
            unset($_SESSION["registered"]);
            echo "problem signing up";
        }

        else
        {
            unset($_SESSION["registered"]);
            echo "Successfully registered";
        }

    }
?>
