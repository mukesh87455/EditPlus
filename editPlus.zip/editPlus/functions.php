<?php
    session_start();
    require_once("configuration.php");
    require_once("db_connection.php");

    function update_editor($editor_text,$editor_title)
    {
        global $mysqli;
        $document_info=$_SESSION["document_info"];

        $query = $mysqli->prepare("INSERT INTO `{$document_info}` 
            SET data=?, title=?
        ");

        $query->bind_param("ss", $editor_text, $editor_title);
        $query->execute();

        return $mysqli->insert_id;
    }


    function get_editor_contents($doc_id) 
    {
      global $mysqli;
      $document_info=$_SESSION["document_info"];

      //to get the latest results 
      $query = $mysqli->prepare("SELECT docid, data, title FROM `{$document_info}` 
          WHERE docid > ? 
          ORDER BY docid DESC 
          LIMIT 1"
        );

      $query->bind_param("i", $doc_id);

      $query->bind_result($new_doc_id, $data, $new_title);
      $query->execute();

      $query->store_result();

      if($query->num_rows == 0) 
      { 
          return false; 
      }
     
      $query->fetch();
      $result = Array();
      $result[] = $new_doc_id;
      $result[] = $data;
      $result[] = $new_title;

      return $result;
    }

?>
