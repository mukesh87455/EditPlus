<?php
    require_once("configuration.php");
    require_once("db_connection.php");

    
    function generateRandomString($length = 6) 
    {
        $characters = 'abcdefghijklmnopqrstuvwxyz';
   
        $charactersLength = strlen($characters);
  
        $randomString = '';
 
        for ($i = 0; $i < $length; $i++) 
        {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
       
        return $randomString;
    }

    //giving variable rows a non-zero value
    $rows="5";

    while($rows!="0")
    { 
        $doc_id=generateRandomString(6);

        //first check whether this is a unique doc_id for published_docs
        $query = $mysqli->prepare("
                                    SELECT COUNT(*)
                                    FROM published_docs
                                    WHERE doc_id=?
                                ");

        $query->bind_param("s",$doc_id);
        $query->execute();
        $query->store_result();

        $query->bind_result($rows);
        $query->fetch();

        //if unique, then insert it
        if($rows=="0")
        {
            $query = $mysqli->prepare("INSERT INTO published_docs
                                       SET doc_id=?, data=?
                                      ");

            $query->bind_param("ss", $doc_id,$_POST["editor_contents"]);
            $query->execute();

            print $doc_id;
        }
    }

