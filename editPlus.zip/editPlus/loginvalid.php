<?php

    session_start();

    require_once("configuration.php");
    require_once("db_connection.php");

    $username=$_POST["username"];
    $password=$_POST["password"];

    $password_hash=crypt($password,$salt);

    $_SESSION['pass']=$password_hash;

    $query = $mysqli->prepare("
                                SELECT *
                                FROM users
                                WHERE username = ?
                                AND password_hash = ? ; 
                            ");

    $query->bind_param("ss", $username,$password_hash);

    $query->execute();
    $result=$query->get_result();
    $row=$result->fetch_assoc();


    if($row)
    {
        //login successful
        $_SESSION["logged"]=true;
        $_SESSION["username"]=$row["username"];

        header("Location: welcome.php");  
    }

    else
    {
        $_SESSION["logged"]=false;
        header("Location: login.php");  
    }

?>
