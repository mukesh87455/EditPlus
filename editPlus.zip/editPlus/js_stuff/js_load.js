$(document).ready(function()
{
    $.get("getVariable.php",function(data)
            {
                if(data!="")
                    alert(data);
                
                if(data=="You need to login to continue")
                {
                    //send back to home
                    location.replace("index.php");
                }

            }
        );
});
