function updateDB()
{
    $.ajax(
            {
                url: "updateDB.php",
                data: {editor_contents : editor_contents, title},
                success: function(result)
                         {
                             doc_id=result;
                         },

                type: "POST",
                dataType: "text"
            });
}

function publish()
{
    $.ajax(
            {
                url: "publish.php",
                data: {editor_contents : editor_contents},
                success: function(result)
                         {
                             var published_token=result;
                             alert("Document Published with doc_id="+published_token);
                             //open this published doc in new tab
                         },

                type: "POST",
                dataType: "text"
            });

}


function collabDB(result, textStatus, jqXHR) 
{
    //alert("call to collabDB.php successful");

    result = $.parseJSON(result); 

    // This is done this way rather than having result come in as JSON using 
    // the jQuery dataType mechanism to allow for the empty string and future 
    // development on this codebase using alternative formats.

    if(result.doc_id*1 > doc_id*1) 
    { 
        // We might have a newer local version already if the user is editing quickly.
        //alert("time to collaborate");

        //$("#editor_field").html(result.data);
        $("#editor_field").val(result.data);
        $("#title").val(result.title);
        doc_id = result.doc_id;
    }

    collaborationCycle(jqXHR,textStatus,"success");
}


//this is for error control
//if the ajax call succeeds, handleEvent function is called
//in case of an error, this function is called again
//The parameter for error function of ajax are xhr, status, error
//initially all these are null, but when this function is called because of error
//the parameters are updated depending upon the error
function collaborationCycle(jqXHR, textStatus, errorThrown) 
{
    $.ajax({
	url: "collabDB.php?doc_id="+doc_id,
	timeout: 100000,
	success: collabDB,
	error: collaborationCycle,
	dataType: "text"
    });
}


$(document).ready(function()
{
    window.editor_contents=""; 
    window.title=""; 
    window.doc_id=0;
    window.temp="";

    $("#editor_field").keyup(function(e)
    {
        //now, update editor in the database
        //if($("#editor_field").html() !=editor_contents)
        if($("#editor_field").val() !=editor_contents)
        {
            //update the database 
            //editor_contents=$("#editor_field").html();
            editor_contents=$("#editor_field").val();
            updateDB();
        }
        
    });
    
    $("#title").keyup(function(e)
    {
        //now, update title
        if($("#title").val() !=title)
        {
            //update the database 
            title=$("#title").val();
            updateDB();
        }
        
    });

    //start collaborationCycle
    collaborationCycle(null, null, null);


});

