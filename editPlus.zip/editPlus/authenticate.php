<?php

    session_start();
    require_once("configuration.php");
    require_once("db_connection.php");

    $token=$_GET["token"];

    $_SESSION["token"]=$token;

    //create table for the editor document for this token
    //name of this table
    //document+token
    $document_info="document_".$_SESSION["token"];
    $_SESSION["document_info"]=$document_info;


    $query = $mysqli->prepare("
                                SELECT COUNT(*)
                                FROM information_schema.tables 
                                WHERE table_schema = 'editplus'
                                AND table_name = ? ;
                            ");

    $query->bind_param("s",$document_info);
    $query->execute();
    $query->store_result();

    $query->bind_result($rows);
    $query->fetch();

    if($rows=="1")
    {
        //check if this user is already in the user_docs table for this document_id
        
        $query = $mysqli->prepare("
                                    SELECT *
                                    FROM user_docs
                                    WHERE doc_id=?
                                    AND username = ? ; 
                                ");

        $query->bind_param("ss", $document_info, $_SESSION["username"]);

        $query->execute();
        $result=$query->get_result();
        $row=$result->fetch_assoc();

        //if found, send to the editor
        if($row)
        {
            header("Location: present.php");  
        }

        //if not found, then add
        //but first check for permissions
        else
        {
            $username=$_SESSION["username"];
            $doc_id=$_SESSION["document_info"];

            $query = $mysqli->prepare("
                                        SELECT *
                                        FROM edit_permits
                                        WHERE doc_id=?
                                    ");

            $query->bind_param("s", $doc_id);
            $query->execute();
            $result=$query->get_result();

            $row=$result->fetch_assoc();
            $edit_status=$row['editable'];

            if($edit_status=='Disabled')
            {
                //you don't have permissions to edit this file
        
                $_SESSION["permit_failure"]=true;
                header("Location: welcome.php");  
            }

            else
            {
                //now, you can add
                $query = $mysqli->prepare("INSERT INTO user_docs
                                           SET doc_id=?, username=?
                                          ");

                $query->bind_param("ss", $document_info,$_SESSION["username"]);
                $query->execute();
            
                $_SESSION['title']="";
                header("Location: present.php");  
            }

        }

    }

    else
    {
        //document does not exist
        
        $_SESSION["doc_validity"]="invalid";
        header("Location: welcome.php");  
    }
?>
