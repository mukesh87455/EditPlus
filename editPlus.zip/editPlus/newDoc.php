<?php

    session_start();
    require_once("configuration.php");
    require_once("db_connection.php");

    function generateRandomString($length = 6) 
    {
        $characters = 'abcdefghijklmnopqrstuvwxyz';
   
        $charactersLength = strlen($characters);
  
        $randomString = '';
 
        for ($i = 0; $i < $length; $i++) 
        {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
       
        return $randomString;
    }

    //giving variable rows a non-zero value
    $rows="5";

    while($rows!="0")
    { 
        $token=generateRandomString(6);

        $_SESSION["token"]=$token;

        //create table for the editor document for this token
        //name of this table
        //document+token
        $document_info="document_".$_SESSION["token"];
        $_SESSION["document_info"]=$document_info;

        //first check whether this is a unique token

        $query = $mysqli->prepare("
                                    SELECT COUNT(*)
                                    FROM information_schema.tables 
                                    WHERE table_schema = 'editplus'
                                    AND table_name = ? ;
                                ");

        $query->bind_param("s",$document_info);
        $query->execute();
        $query->store_result();

        $query->bind_result($rows);
        $query->fetch();

        //if unique, then create it
        if($rows=="0")
        {
            $query = $mysqli->prepare("CREATE TABLE IF NOT EXISTS `{$document_info}`
                                        (
                                            docid INT AUTO_INCREMENT PRIMARY KEY NOT NULL, 
                                            title varchar(20),
                                            data TEXT NOT NULL, 
                                            username VARCHAR(20),
                                            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
                                        );
                                    ");

            $created=$query->execute();

            if($created)
            {
                //now, add this entry to user_docs
                
                $query = $mysqli->prepare("INSERT INTO user_docs
                                           SET doc_id=?, username=?
                                          ");

                $query->bind_param("ss", $document_info,$_SESSION["username"]);
                $query->execute();
        
                $query = $mysqli->prepare("INSERT INTO edit_permits
                                           SET doc_id=?, ownername=?, editable=?
                                          ");

                $permit="Enabled";

                $query->bind_param("sss", $document_info, $_SESSION["username"], $permit);
                $query->execute();

                $_SESSION['title']="";

                header("Location: present.php");  
            }

            else
                header("Location: welcome.php");  
        }

    }
?>
