<?php
require_once('configuration.php');

$mysqli = mysqli_connect($host, $user, $password);

if($mysqli->connect_error) 
{
  die('Unable to connect ('.$mysqli->connect_errno.'): '.$mysqli->connect_error);
}

$db_exists = $mysqli->select_db($db);

if(!$db_exists) 
{
  $query = $mysqli->prepare("CREATE DATABASE ".$mysqli->real_escape_string($db));
  $success = $query->execute();
 
  if(!$success) 
  {
    die("Database does not exist and we were not able to create it.");
  }

  $mysqli->select_db($db);
}

  //create all the tables here

  $query = $mysqli->prepare("CREATE TABLE IF NOT EXISTS users 
                           (
                            username VARCHAR(20) PRIMARY KEY NOT NULL, 
                            fname VARCHAR(12) NOT NULL, 
                            lname VARCHAR(12),
                            password_hash VARCHAR(30) NOT NULL, 
                            gender VARCHAR(6) NOT NULL,
                            dob DATE NOT NULL,
                            mobile VARCHAR(11) NOT NULL,
                            email VARCHAR(50) NOT NULL, 
                            created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
                           );
                        ");

  $query->execute();


  $query2 = $mysqli->prepare("CREATE TABLE IF NOT EXISTS user_docs
                           (
                            doc_id VARCHAR(20) NOT NULL, 
                            username VARCHAR(20) NOT NULL
                           );
                        ");
  $query2->execute();
  
  $query3 = $mysqli->prepare("CREATE TABLE IF NOT EXISTS published_docs
                           (
                            doc_id varchar(10) PRIMARY KEY NOT NULL, 
                            data VARCHAR(2000),
                            created TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
                           );
                        ");

  $query3->execute();

  $query5 = $mysqli->prepare("CREATE TABLE IF NOT EXISTS edit_permits
                           (
                            doc_id VARCHAR(20) NOT NULL, 
                            ownername VARCHAR(20) NOT NULL,
                            editable varchar(12) NOT NULL
                           );
                        ");
  $query5->execute();

?>
