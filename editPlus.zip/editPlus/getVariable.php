<?php

    session_start();
    
    if(!isset($_SESSION["logged"]) || (isset($_SESSION["logged"]) && $_SESSION["logged"]==false))
    {
        echo "You need to login to continue";
    }

    if(isset($_SESSION["doc_validity"]))
    {
        unset($_SESSION["doc_validity"]);

        echo "Document not found";
    }

    if(isset($_SESSION["permit_failure"]))
    {
        unset($_SESSION["permit_failure"]);
        echo "You don't have permissions to edit this file";
    }
?>
