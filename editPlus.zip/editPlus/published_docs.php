<html>
    <head>

        <title>EditPlus - Collaborative Real Time Text Editor</title>
        <link rel="stylesheet" type="text/css" href="styling_stuff/welcome.css">
        
        <script type="text/javascript" src="js_stuff/js_load.js"></script>
        <link rel="icon" type="image/x-icon" href="fav/favicon.ico">

   <meta name="viewport" content="width=device-width, initial-scale=1">
<!--
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>		

-->
  
  <link rel="stylesheet" href="styling_stuff/bootstrap.min.css">
  <script src="js_stuff/jquery.min.js"></script>
  <script src="js_stuff/bootstrap.min.js"></script>		

    </head>

    <body>
	 <div class="container-fluid">
	 
	<header>
	<div class="user"></div>
 <br>	
         <a href="welcome.php" class="btn btn-info" role="button">Homepage</a>

	</header>
	
    <section>
	   
	<div id="published_docs">
	
    <h2 align="center">PUBLISHED DOCUMENTS</h2> 
    <table class="table table-striped table-bordered table-hover" class="mytable"	>
    <thead>
	<tr>
    <th>S.No.</th>
    <th>Document_id</th>
    </tr>
    </thead>
    <?php
        require_once("db_connection.php");

        $query = $mysqli->prepare("
                                    SELECT doc_id
                                    FROM published_docs
                                ");

        $query->execute();
        $result=$query->get_result();

        $i=0;

        while($row=$result->fetch_assoc())
        {
	    $i++;
	    $color=($i%2==0)?"lightblue":"white";
    ?>

        <tr bgcolor="<?php echo $color?>">
        <td><?php echo $i;?></td>
        <td><a href="display_doc.php?id=<?php echo substr($row['doc_id'],0);?>"><?php echo substr($row['doc_id'],0);?></a></td>
        </tr>

    <?php	

        }

        if($i==0)
        { 
            //no documents
            
    ?>
        <h3>No published documents currently</h3>

    <?php	

        }

        $i=0;
    ?>

    </table>

    </div>

	   
	   </section>
	  
       
	</div>
    </body>
</html>

