<?php

session_start();
require_once("db_connection.php");

$document_info=$_SESSION["document_info"];

//to get the latest results 
$query = $mysqli->prepare("SELECT docid FROM `{$document_info}` 
                              ORDER BY docid DESC 
                              LIMIT 1"
                            );

$query->execute();

$result=$query->get_result();
$row=$result->fetch_assoc();

$new_doc_id=$row['docid'];
$title=$_POST['title'];
$_SESSION['title']=$title;

$query = $mysqli->prepare("
                            UPDATE `{$document_info}`
                            SET title=? 
                            WHERE docid=?
                        ");

$query->bind_param("si", $title, $new_doc_id);
$query->execute();

Header("Location: present.php");

?>
