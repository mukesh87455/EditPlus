<?php
    session_start();

    if(!isset($_SESSION["logged"]) || (isset($_SESSION["logged"]) && $_SESSION["logged"]==false))
    {
        /*
        echo '<script language="javascript">';
        echo 'alert("You need to login to continue")';
        echo '</script>';
         */

        //to catch failure
        $_SESSION["failed"]=true;

        header("Location: index.php");
    }


?>

<html>
    <head>

        <title>EditPlus - Collaborative Real Time Text Editor</title>
        <link rel="stylesheet" type="text/css" href="styling_stuff/welcome.css">
        
        <script type="text/javascript" src="js_stuff/js_load.js"></script>
        <link rel="icon" type="image/x-icon" href="fav/favicon.ico">

   <meta name="viewport" content="width=device-width, initial-scale=1">
<!--
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>		

-->
  
  <link rel="stylesheet" href="styling_stuff/bootstrap.min.css">
  <script src="js_stuff/jquery.min.js"></script>
  <script src="js_stuff/bootstrap.min.js"></script>		

    </head>

    <body>
	 <div class="container-fluid">
	 
	<header>
	<div class="user"><?php echo "Welcome ".$_SESSION['username']; ?></div>
	
         <a href="published_docs.php" class="btn btn-info" role="button">Published Documents</a>

	 <a href="logout.php" class="btn btn-info" role="button">LogOut</a>
	
	</header>
	
    <section>
	   
	    <div class="cnd">
	    <a href="newDoc.php" class="btn btn-success" role="button">Create new document</a><br>
        </div>

    <div id="existing">       
    <h2>Open existing document</h2>
     <form name="open_doc" id="open_doc" method="GET" action="authenticate.php">
        <div class="formholder"><input type="text" id="token" name="token" placeholder="Enter document ID"></div>
        <div class="formholder1"><input type="Submit" value="SUBMIT"></div>
        </form>
    </div>

    
	<div id="user_docs">
	

    <h2 align="center">MY DOCUMENTS</h2> 
    <table class="table table-striped table-bordered table-hover" class="mytable"	>
    <thead>
	<tr>
    <th>S.No.</th>
    <th>Document_id</th>
    </tr>
    </thead>
    <?php
        require_once("db_connection.php");

        $username=$_SESSION["username"];

        $query = $mysqli->prepare("
                                    SELECT *
                                    FROM user_docs
                                    WHERE username = ?
                                ");

        $query->bind_param("s", $username);

        $query->execute();
        $result=$query->get_result();

        $i=0;

        while($row=$result->fetch_assoc())
        {
	    $i++;
	    $color=($i%2==0)?"lightblue":"white";
    ?>

        <tr bgcolor="<?php echo $color?>">
        <td><?php echo $i;?></td>
        <td><a href="authenticate.php?token=<?php echo substr($row['doc_id'],9);?>"><?php echo substr($row['doc_id'],9);?></a></td>
        </tr>

    <?php	

        }

        if($i==0)
        { 
            //no documents
            
    ?>
        <h3>You don't have any documents currently</h3>

    <?php	

        }

        $i=0;
    ?>

    </table>

    </div>

	   
	   </section>
	  
       
	</div>
    </body>
</html>

