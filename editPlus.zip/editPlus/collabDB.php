<?php

require_once("functions.php");

session_write_close(); 
// to avoid sleeping with the session open.

$doc_id = intval($_GET["doc_id"]);

while(true) 
{ 
    // If the client is up to date we have to wait for new data.
    if($editor_contents = get_editor_contents($doc_id)) 
    {
        $msg = Array();
        $msg["doc_id"] = $editor_contents[0];
        $msg["data"] = $editor_contents[1];
        $msg["title"] = $editor_contents[2];

        print(json_encode($msg));

        exit(0);
    }
    
    sleep(1); 
    // But we don't want to hog the CPU if other processes need it.
}

?>
