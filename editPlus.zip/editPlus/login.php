<!Doctype html>
<html>
<head>
    <title>EDITPLUS LOGIN</title>

  <link rel="stylesheet" href="styling_stuff/login.css" type="text/html">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  <script type="text/javascript" src="js_stuff/js_login.js"></script>
  <link rel="icon" type="image/x-icon" href="fav/favicon.ico">

</head>


<body>

<header>
  <div class="title">WELCOME TO EDITPLUS LOGIN</div>
</header>

<div class="container">

  <section>
    <div class="main">

      <form action="loginvalid.php" method="POST">

        <div class="formholder inner-addon left-addon"> <i class="glyphicon glyphicon-user"></i><input type="text" name="username"  placeholder="USERNAME" maxlength="10" required></div><br>

        <div class="formholder inner-addon left-addon"><i class="glyphicon glyphicon-lock"></i><input type="password" name="password" placeholder="PASSWORD" maxlength="10" required></div><br><br>

        <div class="formholder"><input type="submit" value="SUBMIT"></div><br><br>

      </form>

        <div class="formholder1"><input type="button" value="FORGET PASSWORD"></div>
        <div class="GB"><a href="index.php" class="btn btn-primary" role="button">Go Back</a></div>
        <div class="CaA"><a href="signup.php" class="btn btn-primary" role="button">Create an Account</a></div>
        
      </fieldset>
    </div>
  </section>

</div>
</body>
</html>
