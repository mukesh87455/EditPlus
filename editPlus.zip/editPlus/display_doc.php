<?php

    if(!isset($_GET['id']))
    {
        //error message and back to published docs
        echo '<script language="javascript">';
        echo 'alert("ERROR: No such document exists")';
        echo '</script>';

        echo '<script language="javascript">';
        echo 'location.replace("published_docs.php")';
        echo '</script>';

    }

    else
    {
        $doc_id=$_GET['id'];

        if($doc_id=='')
        {
            //error message and back to published docs
            echo '<script language="javascript">';
            echo 'alert("ERROR: No such document exists")';
            echo '</script>';

            echo '<script language="javascript">';
            echo 'location.replace("published_docs.php")';
            echo '</script>';

        }
    }


    require_once("db_connection.php");

    $query = $mysqli->prepare("
                                SELECT data, doc_id
                                FROM published_docs
                                WHERE doc_id=?
                            ");


    $query->bind_param("s", $doc_id);
    $query->execute();
    $result=$query->get_result();
    $row=$result->fetch_assoc();
    
    if($row['doc_id']=='')
    {
        //error message and back to published docs
        echo '<script language="javascript">';
        echo 'alert("ERROR: No such document exists")';
        echo '</script>';

        echo '<script language="javascript">';
        echo 'location.replace("published_docs.php")';
        echo '</script>';
    }

?>

<html>
    <head>

        <title>EditPlus - Collaborative Real Time Text Editor</title>
        <link rel="stylesheet" type="text/css" href="styling_stuff/welcome.css">
        
        <script type="text/javascript" src="js_stuff/js_load.js"></script>
        <link rel="icon" type="image/x-icon" href="fav/favicon.ico">

   <meta name="viewport" content="width=device-width, initial-scale=1">
<!--
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>		

-->
  
  <link rel="stylesheet" href="styling_stuff/bootstrap.min.css">
  <script src="js_stuff/jquery.min.js"></script>
  <script src="js_stuff/bootstrap.min.js"></script>		
  <script src="js_stuff/publish.js"></script>		

    <script type="text/javascript" src="js_stuff/jquery-linedtextarea.js"></script>
    <link rel="stylesheet" type="text/css" href="styling_stuff/editor_published.css">
    <link rel="stylesheet" type="text/css" href="styling_stuff/jquery-linedtextarea.css">

    </head>

    <body>
	 <div class="container-fluid">
	 
	<header>
        <div class="user" id="doc_id"><?php echo $doc_id;?></div>
         <a href="published_docs.php" class="btn btn-info" role="button">Go Back</a>
         <a href="" onclick='saveTextAsFile()' class="btn btn-info" role="button">Download document</a>

	</header>
	

    <section>
	   
	<div id="published_docs">
	
    <h2 align="center">Document</h2> 

    <div id="box">
        <div id="editor">

        <textarea id="editor_field" readonly class="lined" >

    <?php

        echo $row['data'];
    ?>

</textarea>

                </div>
                </div>
                </div>
                
<script>
$(function() {
	$(".lined").linedtextarea(
		{selectedLine: 0}
	);
});
</script>

    </div>

	   
	   </section>
	  
       
	</div>
    </body>
</html>

