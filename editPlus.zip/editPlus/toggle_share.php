<?php

session_start();
require_once("db_connection.php");

$username=$_SESSION["username"];
$doc_id=$_SESSION["document_info"];

$query = $mysqli->prepare("
                            SELECT *
                            FROM edit_permits
                            WHERE doc_id=?
                        ");

$query->bind_param("s", $doc_id);
$query->execute();
$result=$query->get_result();

$row=$result->fetch_assoc();
$edit_status=$row['editable'];

if($edit_status=='Disabled')
{
    $edit_status='Enabled';
}

else
{
    $edit_status='Disabled';
}

$query = $mysqli->prepare("
                            UPDATE edit_permits
                            SET editable=?
                            WHERE doc_id=?
                        ");

$query->bind_param("ss", $edit_status, $doc_id);
$query->execute();

Header("Location: present.php");

?>
