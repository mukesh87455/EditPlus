<?php

    session_start();

    require_once("configuration.php");
    require_once("db_connection.php");

    $query = $mysqli->prepare("INSERT INTO users SET fname=?, lname=?, username=?, password_hash=?, dob=?, gender=?, mobile=?, email=?");

    $fname=$_POST["fname"];
    $lname=$_POST["lname"];
    $username=$_POST["username"];
    $password=$_POST["password"];
    $dob=$_POST["dob"];
    $gender=$_POST["gender"];
    $mobile=$_POST["mobile"];
    $email=$_POST["email"];

    $password_hash=crypt($password,$salt);
    
    $query->bind_param("ssssssss", $fname, $lname, $username, $password_hash, $dob, $gender, $mobile, $email);
    $result=$query->execute();

    if($result)
    {
        //registration successful
        $_SESSION["registered"]=true;

        header("Location: index.php");  
    }

    else
    {
        $_SESSION["registered"]=false;
        header("Location: signup.php");  
    }

?>
