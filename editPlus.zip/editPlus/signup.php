<!DOCTYPE html>

<html>
<head>
    <title>EDITPLUS REGISTRATION</title>
    <link rel="stylesheet" type="text/css" href="styling_stuff/signup.css">
  
    <script type="text/javascript" src="js_stuff/js_register.js"></script>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link rel="icon" type="image/x-icon" href="fav/favicon.ico">
</head>
<body>

 
<header>
 <div class="title">WELCOME TO EDITPLUS REGISTRATION</div>
  </header>
 <div class="container-fluid">
   <form action="registrationValid.php" method="post">
      <table>
        <tr>
          <td>FIRST NAME:</td>
          <td><div class="formholder"><input type="text" placeholder="FirstName" name="fname" required></div></td>
        </tr>
        <tr>
          <td>LAST NAME</td>
          <td><div class="formholder"><input type="text" placeholder="LastName" name="lname"></div></td>
        </tr>
        <tr>
          <td>USERNAME</td>
          <td><div class="formholder"><input type="text" placeholder="Username/UserID" name="username" required></div></td>
        </tr>
        <tr>
          <td>PASSWORD</td>
          <td><div class="formholder"><input type="password" name="password" required></div></td>
        </tr>
        <tr>
          <td>DATE OF BIRTH</td>
          <td><div class="formholder"><input type="date" name="dob"></div></td>
        </tr>
        <tr>
          <td>GENDER</td>
          <td><input type="radio" name="gender" value="male" checked>Male
              <input type="radio" name="gender" value="femlae">Female</td>
        </tr>
        <tr>
          <td>MOBILE NO.</td>
          <td><div class="formholder"><input type="number" name="mobile" required></div></td>
        </tr>
        <tr>
          <td>EMAIL</td>
          <td><div class="formholder"><input type="email" name="email" required></div></td>
        </tr>
        </table>
       <div class="formholder1"><input type="submit" name="submit" value="SUBMIT"></div>
   </form>
      <ul class="pager">
       <li class="previous"><a href="index.php">Go Back</a></li>
	   <li class="next"><a href="login.php">Already have an account?</a></li>
      </ul>
        
</div>
		</body>
</html>
