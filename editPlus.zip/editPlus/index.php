<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>EditPlus - Collaborative Real Time Text Editor</title>
        <link rel="stylesheet" type="text/css" href="styling_stuff/index.css">
        
        <meta name="viewport" content="width=device-width , initial-scale=1">
        
<!--
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>		

-->
  
  <link rel="stylesheet" href="styling_stuff/bootstrap.min.css">
  <script src="js_stuff/jquery.min.js"></script>
  <script src="js_stuff/bootstrap.min.js"></script>		

	<link rel="icon" type="image/x-icon" href="fav/favicon.ico">
        
        </head>



<?php

    session_start();
    
    if(isset($_SESSION["failed"]))
    {
        echo '<script language="javascript">';
        echo 'alert("You need to login to continue")';
        echo '</script>';
    }

    if(isset($_SESSION["registered"]))
    {
        if($_SESSION["registered"]==false)
        {
            echo '<script language="javascript">';
            echo 'alert("Problem signing up")';
            echo '</script>';
        }

        else
        {
            echo '<script language="javascript">';
            echo 'alert("Successfully registered")';
            echo '</script>';
        }

    }

    session_unset();
    session_destroy();
?>



    <body>
	    <nav class="navbar navbar-default">
		<div class="container-fluid">
		 <div class="navbar-header">
		  <a class="navbar-brand">EditPlus</a>
		 </div>
		 <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">

        <li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>

        <li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>

      </ul>
    </div>
		</div>
        </nav>
  
     <section>
    <article>
      <table>
        <tr height="110px">
          <td width="500px" bgcolor="#1E90FF">Now code easily on our EDITPLUS  without any hesitation. You can code in any language JAVA , html , php, and many more.</td>
          <td width="500px" height="300px" bgcolor="#1E90FF"><img src="editorimg1.png" width="100%" height="300px"></td>
        </tr>
      </table>
    </article>
	<article>
      <div class="label1">
        <table>
          <tr height="110px">
            <td width="500px" bgcolor="#cd5c5c"><img src="editorimg2.png" width="100%" height="300px"></td>
            <td width="500px" bgcolor="#cd5c5c">You can chat while you can writing your code.Share your code to your friends and increase your knowledge.</td>
          </tr>
        </table>
      </div>
    </article>
    
  </section>
   
		
    </div>
    </body>
</html>

