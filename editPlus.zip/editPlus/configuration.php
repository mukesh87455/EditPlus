<?php
    $host = "localhost";
    $user = "root";
    $password = ""; 
    $db = "editplus";
    $salt="darkRnger";
?>
